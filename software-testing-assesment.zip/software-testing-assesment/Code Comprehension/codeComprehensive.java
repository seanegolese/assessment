package com.example.automationSolution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.*;

@SpringBootApplication
public class AutomationSolutionApplication {

	private static final Scanner scanner = new Scanner(System.in);
	public static void main(String[] args) {
		SpringApplication.run(AutomationSolutionApplication.class, args);


		int[] arr = new int[5];

		String[] arrItems = scanner.nextLine().split(" ");
		scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");

		for (int i = 0; i < 5; i++) {
			int arrItem = Integer.parseInt(arrItems[i]);
			arr[i] = arrItem;
		}

 		miniMaxSum(arr);

		scanner.close();
	}


	static void miniMaxSum(int[] arr) {
		long[] longs = Arrays.stream(arr).asLongStream().toArray();
		Arrays.sort(longs);


		long min1 = 0;
		for(int i=0;i<longs.length-1;i++)
		{
			min1+=longs[i];
		}

		long max1 = 0;
		for(int i=1;i<longs.length;i++)
		{
			max1+=longs[i];
		}


		System.out.println(min1 + " " + max1);

	}

}

package com.example.automationSolution;

class AutomationSolutionApplicationTests {
	void contextLoads() {
	}
}

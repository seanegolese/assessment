package com.example.automationSolution.Framework;

public class PageObject {
    public PageObject() {
    }

    private String Key;
    private String Xpath;
    public String getKey() {
        return Key;
    }

    public String getXpath() {
        return Xpath;
    }

    public void setKey(String key) {
        Key = key;
    }

    public void setXpath(String xpath) {
        Xpath = xpath;
    }


}

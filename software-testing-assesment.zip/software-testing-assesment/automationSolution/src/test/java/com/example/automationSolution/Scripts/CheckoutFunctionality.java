package com.example.automationSolution.Scripts;

import com.example.automationSolution.Framework.AssessmentDataProvider;
import com.example.automationSolution.Framework.Executor;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;

public class CheckoutFunctionality extends Executor {

    @Test(priority = 1,dataProvider = "Credentials",dataProviderClass = AssessmentDataProvider.class)
    public void Login(String username,String password) {
        NavigateToUrl("https://www.saucedemo.com/");
        InputValue("textUsername", username);
        InputValue("txtPassword",password);
        Click("btnLogin");
    }

    @Test(priority = 2,dataProvider = "Products-to-buy",dataProviderClass = AssessmentDataProvider.class)
    public void AddProductsToCart(String product,int quantity) {
        Click("item",product);
    }


    @Test(priority = 3)
    public void Checkout()  {
        Click("btnShoppingCart");
    }

    @Test(priority = 4,dataProvider = "Products-to-buy",dataProviderClass = AssessmentDataProvider.class)
    public void ConfirmProductCorrectProductsAreAdded(String product,int quantity) throws InterruptedException {
        Assert.assertEquals(GetText("confirmProductName",product),product);
        Assert.assertEquals(Integer.parseInt(GetText("confirmProductQuantity",product)),quantity);
    }

    @Test(priority = 5,dataProvider = "Personal-Information",dataProviderClass = AssessmentDataProvider.class)
    public void CaptureInformation(String firstName,String lastName,String postalCode)
    {
        Click("btnCheckout");
        InputValue("txtFirstName", firstName);
        InputValue("txtLastName", lastName);
        InputValue("txtPostCode",postalCode);
        Click("btnContinue");
    }

    @Test(priority = 6)
    public void VerifyOrderDetails()
    {
        List<WebElement> CartPriceElementList =GetElements("lstCartPrices");

        double cartTotal = 0;

        for (WebElement element:CartPriceElementList) {
            cartTotal += Double.parseDouble(element.getText().replace("$",""));
        }

        double total = Double.parseDouble(GetText("lblSubTotal").replace("Item total: $",""));
        Assert.assertEquals(cartTotal, total);
    }

    @Test(priority = 7)
    public void CompleteOrder()
    {
        Click("btnFinish");
        Assert.assertEquals(GetText("lblCompleteText"), "THANK YOU FOR YOUR ORDER");
    }
}

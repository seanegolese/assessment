package com.example.automationSolution.Framework;

import org.junit.After;
import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Stream;


public class Executor {

    public static WebDriver driver;
    public static Map<String,String> mapping;

    public Executor(){

    }


@BeforeTest
public static void SetupEnvironment()
{
    System.setProperty("webdriver.chrome.driver", "./src/test/driver/chromedriver.exe");
    driver = new ChromeDriver();
    driver.manage().window().maximize();
    mapping= GetMapping();
}

    @After
    private void CleanEnvironment()
    {
        driver.quit();
    }

    public void NavigateToUrl(String url)
    {
        driver.get(url);
    }

    private void HighlightFoundElement(WebElement element) {
        try
        {
            String originalColor = element.getCssValue("border-bottom-color");

            JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
            jsExecutor.executeScript("arguments[0].style.border='2px solid red'", element);
            Thread.sleep(60);
            jsExecutor.executeScript("arguments[0].style.border='"+originalColor+"'", element);
        }
        catch (Exception e)
        {

        }
    }
    private WebElement GetElement(String mappedObject)
    {
        WebElement element = driver.findElement(By.xpath(mapping.get(mappedObject)));
        HighlightFoundElement(element);
        return element;
    }

    private WebElement GetElement(String mappedObject,String xpathValue)
    {
        String xpath = mapping.get(mappedObject).replace("xpathValue",xpathValue);
         WebElement element =  driver.findElement(By.xpath(xpath));
         HighlightFoundElement(element);
        return element;
    }
    public List<WebElement> GetElements(String mappedObject)
    {
        return driver.findElements(By.xpath(mapping.get(mappedObject)));
    }

     public void InputValue(String mappedObject,String value)
     {
         GetElement(mappedObject).sendKeys(value);
     }
     public void Click(String mappedObject)
     {
         GetElement(mappedObject).click();
     }

    public void Click(String mappedObject,String xpathValue)
    {
        GetElement(mappedObject,xpathValue).click();
    }

    public String GetText(String mappedObject)
    {
       return GetElement(mappedObject).getText();
    }

    public String GetText(String mappedObject,String xpathValue)
    {
        return GetElement(mappedObject,xpathValue).getText();
    }


    private static Map<String, String> GetMapping() {
        Map<String, String> map = new HashMap<>();
        try (Stream<String> lines = Files.lines(Paths.get("./src/test/ObjectMapping/objectmapping.txt"))) {
            lines.filter(line -> line.contains(":"))
                    .forEach(line -> {
                        String[] keyValuePair = line.split(":", 2);
                        String key = keyValuePair[0];
                        String value = keyValuePair[1];

                        map.put(key, value);

                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return map;
    }

}

package com.example.automationSolution.Framework;
import org.testng.annotations.DataProvider;

public class AssessmentDataProvider {
    @DataProvider(name = "Credentials")
    public Object[][] Credentials()
    {
        return new Object[][]{{"standard_user","secret_sauce"}};
    }
    @DataProvider(name = "Products-to-buy")
    public Object[][] ProductsToBuy()
    {
        return new Object[][]{{"Sauce Labs Backpack",1},{"Sauce Labs Bike Light",1},{"Sauce Labs Onesie",1}};
    }
    @DataProvider(name = "Personal-Information")
    public Object[][] PersonalInformation()
    {
        return new Object[][]{{"Lesetja","Seanego","1685"}};
    }
}

--amount_of_customers.sql
SELECT Count(customer_id) as Number_of_Customers
from customers



--avg_reports_per_employee.sql 
SELECT *
FROM employees
where  reports_to >(select AVG(reports_to) FROM employees);


--customer_with_most_orders.sql
SELECT count(o.order_id),c.company_name
FROM Customers c right join Orders o
on c.customer_id = o.customer_id
group by c.customer_id order by 1 desc
fetch first 1 row only;


--orders_per_calendar.sql 
SELECT DATE_PART('YEAR', order_date) AS published_year,COUNT(order_id) AS count
FROM Orders
where DATE_PART('YEAR', order_date) > '1995'
GROUP BY DATE_PART('YEAR', order_date)
order by 1 desc;


--orders_by_customer.sql 
SELECT count(o.order_id), c.company_name
from Customers c right join Orders o
on c.customer_id=o.customer_id left join Shippers s
on o.ship_via = s.shipper_id
where c.company_name = 'Simons bistro'
and s.company_name = 'United Package'
group by c.company_name;




